package earth.terrarium.cloche

import earth.terrarium.cloche.api.MappingsBuilder
import earth.terrarium.cloche.api.attributes.CompilationAttributes
import earth.terrarium.cloche.api.attributes.IncludeTransformationStateAttribute
import earth.terrarium.cloche.api.attributes.MinecraftModLoader
import earth.terrarium.cloche.api.attributes.ModDistribution
import earth.terrarium.cloche.api.metadata.RootMetadata
import earth.terrarium.cloche.api.target.*
import earth.terrarium.cloche.target.common.CommonTargetInternal
import earth.terrarium.cloche.target.fabric.FabricTargetImpl
import earth.terrarium.cloche.target.forge.lex.ForgeTargetImpl
import earth.terrarium.cloche.target.forge.neo.NeoForgeTargetImpl
import net.msrandom.minecraftcodev.core.utils.extension
import net.msrandom.minecraftcodev.fabric.FabricInstallerComponentMetadataRule
import net.msrandom.minecraftcodev.includes.ExtractIncludes
import net.msrandom.minecraftcodev.includes.StripIncludes
import org.gradle.api.*
import org.gradle.api.artifacts.type.ArtifactTypeDefinition
import org.gradle.api.file.DirectoryProperty
import org.gradle.api.model.ObjectFactory
import org.gradle.api.plugins.BasePlugin
import org.gradle.api.plugins.BasePluginExtension
import org.gradle.api.provider.Property
import org.gradle.kotlin.dsl.*
import javax.inject.Inject

internal val Project.cloche
    get() = extension<ClocheExtension>()

internal val Project.modId
    get() = cloche.metadata.modId

internal fun loader(type: Class<out MinecraftTarget>) = when {
    ForgeTarget::class.java.isAssignableFrom(type) -> MinecraftModLoader.forge
    FabricTarget::class.java.isAssignableFrom(type) -> MinecraftModLoader.fabric
    NeoforgeTarget::class.java.isAssignableFrom(type) -> MinecraftModLoader.neoforge
    else -> throw IllegalArgumentException("Unknown target type $type")
}

@JvmDefaultWithoutCompatibility
interface SimpleTargetContainer {
    fun fabric(configure: Action<FabricTarget>): FabricTarget
    fun forge(configure: Action<ForgeTarget>): ForgeTarget
    fun neoforge(configure: Action<NeoforgeTarget>): NeoforgeTarget
}

class SingleTargetConfigurator(private val project: Project, private val extension: ClocheExtension) : SimpleTargetContainer {
    internal var target: MinecraftTarget? = null

    override fun fabric(configure: Action<FabricTarget>) = target(FabricTargetImpl::class.java, configure)
    override fun forge(configure: Action<ForgeTarget>) = target(ForgeTargetImpl::class.java, configure)
    override fun neoforge(configure: Action<NeoforgeTarget>) = target(NeoForgeTargetImpl::class.java, configure)

    private fun <T : MinecraftTarget> target(type: Class<out T>, configure: Action<T>): T {
        val loaderName = loader(type)

        extension.targets.configureEach {
            throw UnsupportedOperationException("Target '$targetName' has been configured. Can not set single target to '$loaderName'")
        }

        extension.commonTargets.configureEach {
            throw UnsupportedOperationException("Common target '$targetName' has been configured. Can not use single target mode with target '$loaderName'")
        }

        target?.let {
            if (!type.isAssignableFrom(it.javaClass)) {
                throw UnsupportedOperationException("Single target is set as type '${it.loaderName}', but was queried as type '$loaderName'")
            }

            @Suppress("UNCHECKED_CAST")
            configure.execute(it as T)

            return it
        }

        val instance = project.objects.newInstance(type, "")

        extension.singleTargetSetCallback(type, instance)

        addTarget(extension, project, instance)

        return instance.also(configure::execute).also {
            target = it
        }
    }
}

open class ClocheExtension @Inject constructor(private val project: Project, objects: ObjectFactory) : SimpleTargetContainer {
    val minecraftVersion: Property<String> = objects.property<String>()

    val commonTargets: NamedDomainObjectContainer<CommonTarget> = objects.domainObjectContainer(CommonTarget::class) {
        objects.newInstance<CommonTargetInternal>(it)
    }

    val targets: PolymorphicDomainObjectContainer<MinecraftTarget> = objects.polymorphicDomainObjectContainer(MinecraftTarget::class).apply {
        registerFactory(FabricTarget::class.java) {
            objects.newInstance<FabricTargetImpl>(it)
        }

        registerFactory(ForgeTarget::class.java) {
            objects.newInstance<ForgeTargetImpl>(it)
        }

        registerFactory(NeoforgeTarget::class.java) {
            objects.newInstance<NeoForgeTargetImpl>(it)
        }
    }

    val metadata: RootMetadata = objects.newInstance<RootMetadata>()

    val intermediateOutputsDirectory: DirectoryProperty = objects.directoryProperty()
    val finalOutputsDirectory: DirectoryProperty = objects.directoryProperty()

    internal val singleTargetConfigurator = SingleTargetConfigurator(project, this)

    @Suppress("UNCHECKED_CAST")
    internal val mappingActions = project.objects.domainObjectSet(Action::class) as DomainObjectCollection<Action<MappingsBuilder>>

    private val singleTargetCallbacks = hashMapOf<Class<out MinecraftTarget>, (target: MinecraftTarget) -> Unit>()

    internal val intermediaryMinecraftProviders = project.objects.newInstance(DefinedMinecraftProviders::class.java)

    private fun onTargetTypeConfigured(type: Class<out MinecraftTarget>, action: (target: MinecraftTarget) -> Unit) {
        var configured = false

        val set = targets.withType(type)

        set.whenObjectAdded {
            if (!configured) {
                configured = true

                action(this)
            }
        }

        singleTargetCallbacks[type] = action
    }

    internal fun singleTargetSetCallback(type: Class<out MinecraftTarget>, target: MinecraftTarget) = singleTargetCallbacks.entries.filter {
        it.key.isAssignableFrom(type)
    }.forEach { it.value.invoke(target) }

    init {
        project.dependencies.registerTransform(ExtractIncludes::class) {
            from
                .attribute(ArtifactTypeDefinition.ARTIFACT_TYPE_ATTRIBUTE, ArtifactTypeDefinition.JAR_TYPE)
                .attribute(IncludeTransformationStateAttribute.ATTRIBUTE, IncludeTransformationStateAttribute.None)

            to
                .attribute(ArtifactTypeDefinition.ARTIFACT_TYPE_ATTRIBUTE, ArtifactTypeDefinition.JAR_TYPE)
                .attribute(IncludeTransformationStateAttribute.ATTRIBUTE, IncludeTransformationStateAttribute.Extracted)
        }

        project.dependencies.registerTransform(StripIncludes::class) {
            from
                .attribute(ArtifactTypeDefinition.ARTIFACT_TYPE_ATTRIBUTE, ArtifactTypeDefinition.JAR_TYPE)
                .attribute(IncludeTransformationStateAttribute.ATTRIBUTE, IncludeTransformationStateAttribute.None)

            to
                .attribute(ArtifactTypeDefinition.ARTIFACT_TYPE_ATTRIBUTE, ArtifactTypeDefinition.JAR_TYPE)
                .attribute(IncludeTransformationStateAttribute.ATTRIBUTE, IncludeTransformationStateAttribute.Stripped)
        }

        project.plugins.withType<BasePlugin> {
            val libs = project.extension<BasePluginExtension>().libsDirectory

            intermediateOutputsDirectory.convention(libs.dir("intermediates"))
            finalOutputsDirectory.convention(libs)
        }

        onTargetTypeConfigured(FabricTarget::class.java) {
            project.dependencies.components {
                withModule("net.fabricmc:fabric-loader", FabricInstallerComponentMetadataRule::class) {
                    params(CompilationAttributes.DISTRIBUTION, ModDistribution.common, ModDistribution.client, false)
                }
            }
        }

        targets.configureEach {
            dependsOn(common())
        }

        commonTargets
            .named { it != MinecraftModLoader.common.name }
            .configureEach { dependsOn(common()) }

        // afterEvaluate needed as we are querying the configuration of a value
        project.afterEvaluate {
            if ((targets.isNotEmpty() || singleTargetConfigurator.target != null) && !metadata.modId.isPresent) {
                throw InvalidUserCodeException("`cloche.metadata.modId` was not set in $project.")
            }
        }
    }

    // Useless to call from an outside context
    private fun common(): CommonTarget = common(MinecraftModLoader.common.name)

    fun common(name: String): CommonTarget = common(name) {}
    fun common(configure: Action<CommonTarget>): CommonTarget = common(MinecraftModLoader.common.name, configure)

    fun common(name: String, configure: Action<CommonTarget>): CommonTarget =
        commonTargets.maybeCreate(name).also(configure::execute)

    override fun fabric(configure: Action<FabricTarget>): FabricTarget = fabric(MinecraftModLoader.fabric.name, configure)

    fun fabric(name: String, configure: Action<FabricTarget>): FabricTarget = target(name, configure)

    override fun forge(configure: Action<ForgeTarget>): ForgeTarget = forge(MinecraftModLoader.forge.name, configure)

    fun forge(name: String, configure: Action<ForgeTarget>): ForgeTarget = target(name, configure)

    override fun neoforge(configure: Action<NeoforgeTarget>): NeoforgeTarget = neoforge(MinecraftModLoader.neoforge.name, configure)

    fun neoforge(name: String, configure: Action<NeoforgeTarget>): NeoforgeTarget = target(name, configure)

    fun <T : MinecraftTarget> singleTarget(configurator: SingleTargetConfigurator.() -> T) = singleTargetConfigurator.configurator()

    private fun <T : MinecraftTarget> target(name: String, type: Class<T>, configure: Action<in T>) =
        targets.maybeCreate(name, type).also(configure::execute)

    private inline fun <reified T : MinecraftTarget> target(name: String, configure: Action<in T>) =
        target(name, T::class.java, configure)

    fun mappings(action: Action<MappingsBuilder>) {
        mappingActions.add(action)
    }

    fun metadata(action: Action<RootMetadata>) {
        action.execute(metadata)
    }
}
