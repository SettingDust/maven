package net.msrandom.minecraftcodev.remapper.task

import net.fabricmc.mappingio.format.tiny.Tiny2FileReader
import net.fabricmc.mappingio.format.tiny.Tiny2FileWriter
import net.fabricmc.mappingio.tree.MemoryMappingTree
import net.msrandom.minecraftcodev.core.task.CachedMinecraftTask
import net.msrandom.minecraftcodev.core.utils.cacheExpensiveOperation
import net.msrandom.minecraftcodev.core.utils.getAsPath
import net.msrandom.minecraftcodev.remapper.FieldAddDescVisitor
import net.msrandom.minecraftcodev.remapper.FieldRemoveNullDescVisitor
import net.msrandom.minecraftcodev.remapper.loadMappings
import org.gradle.api.file.ConfigurableFileCollection
import org.gradle.api.file.RegularFileProperty
import org.gradle.api.provider.Property
import org.gradle.api.tasks.CacheableTask
import org.gradle.api.tasks.Input
import org.gradle.api.tasks.InputFiles
import org.gradle.api.tasks.Internal
import org.gradle.api.tasks.OutputFile
import org.gradle.api.tasks.PathSensitive
import org.gradle.api.tasks.PathSensitivity
import org.gradle.api.tasks.TaskAction
import org.gradle.process.ExecOperations
import java.nio.file.Path
import javax.inject.Inject
import kotlin.io.path.bufferedWriter
import kotlin.io.path.reader

const val LOAD_MAPPINGS_OPERATION_VERSION = 3

internal fun loadCachedMappingFile(input: Path) = MemoryMappingTree().also {
    Tiny2FileReader.read(input.reader(), FieldRemoveNullDescVisitor(it))
}

@CacheableTask
abstract class LoadMappings : CachedMinecraftTask() {
    abstract val mappings: ConfigurableFileCollection
        @InputFiles
        @PathSensitive(PathSensitivity.NONE)
        get

    abstract val output: RegularFileProperty
        @OutputFile
        get

    abstract val javaExecutable: RegularFileProperty
        @Internal get

    abstract val execOperations: ExecOperations
        @Inject get

    abstract val namedSrg: Property<Boolean>
        @Input get


    init {
        namedSrg.convention(false)
        run {
            output.set(temporaryDir.resolve("mappings.tiny"))
        }
    }

    @TaskAction
    fun load() {
        cacheExpensiveOperation(cacheParameters.directory.getAsPath(), "mappings-$LOAD_MAPPINGS_OPERATION_VERSION", mappings.map { it.toPath() }, output.getAsPath()) { (output) ->
            val mappings = loadMappings(mappings, javaExecutable.get(), cacheParameters, execOperations, namedSrg.get())

            output.bufferedWriter().use { writer ->
                mappings.accept(FieldAddDescVisitor(Tiny2FileWriter(writer, false)))
            }
        }
    }
}
