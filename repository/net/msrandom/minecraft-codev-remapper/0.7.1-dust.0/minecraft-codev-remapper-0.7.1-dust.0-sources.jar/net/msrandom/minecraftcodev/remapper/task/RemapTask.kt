package net.msrandom.minecraftcodev.remapper.task

import net.msrandom.minecraftcodev.core.utils.cacheExpensiveOperation
import net.msrandom.minecraftcodev.core.utils.getAsPath
import net.msrandom.minecraftcodev.core.utils.getGlobalCacheDirectoryProvider
import net.msrandom.minecraftcodev.remapper.JarRemapper
import net.msrandom.minecraftcodev.remapper.MinecraftCodevRemapperPlugin
import net.msrandom.minecraftcodev.remapper.REMAP_OPERATION_VERSION
import org.gradle.api.DefaultTask
import org.gradle.api.file.ConfigurableFileCollection
import org.gradle.api.file.DirectoryProperty
import org.gradle.api.file.RegularFileProperty
import org.gradle.api.model.ObjectFactory
import org.gradle.api.provider.Property
import org.gradle.api.tasks.CacheableTask
import org.gradle.api.tasks.CompileClasspath
import org.gradle.api.tasks.Input
import org.gradle.api.tasks.InputFile
import org.gradle.api.tasks.InputFiles
import org.gradle.api.tasks.Internal
import org.gradle.api.tasks.Optional
import org.gradle.api.tasks.OutputFile
import org.gradle.api.tasks.PathSensitive
import org.gradle.api.tasks.PathSensitivity
import org.gradle.api.tasks.TaskAction
import org.gradle.workers.WorkAction
import org.gradle.workers.WorkParameters
import org.gradle.workers.WorkerExecutor
import java.nio.file.Path
import javax.inject.Inject

@CacheableTask
abstract class RemapTask : DefaultTask() {
    abstract val inputFile: RegularFileProperty
        @InputFile
        @PathSensitive(PathSensitivity.RELATIVE)
        get

    abstract val sourceNamespace: Property<String>
        @Input get

    abstract val targetNamespace: Property<String>
        @Optional
        @Input
        get

    abstract val mappings: RegularFileProperty
        @InputFile
        @PathSensitive(PathSensitivity.NONE)
        get

    abstract val classpath: ConfigurableFileCollection
        @InputFiles
        @CompileClasspath
        get

    abstract val cacheDirectory: DirectoryProperty
        @Internal get

    abstract val outputFile: RegularFileProperty
        @OutputFile get

    abstract val objectFactory: ObjectFactory
        @Inject get

    abstract val workerExecutor: WorkerExecutor
        @Inject get

    init {
        run {
            outputFile.convention(
                project.layout.file(
                    inputFile.flatMap { file ->
                        targetNamespace.map { namespace ->
                            temporaryDir.resolve("${file.asFile.nameWithoutExtension}-$namespace.${file.asFile.extension}")
                        }
                    },
                ),
            )

            targetNamespace.convention(MinecraftCodevRemapperPlugin.NAMED_MAPPINGS_NAMESPACE)

            cacheDirectory.set(getGlobalCacheDirectoryProvider(project))
        }
    }

    @TaskAction
    fun remap() {
        val workQueue = workerExecutor.noIsolation()

        workQueue.submit(RemapWorkAction::class.java) {
            inputFile.set(this@RemapTask.inputFile)
            sourceNamespace.set(this@RemapTask.sourceNamespace)
            targetNamespace.set(this@RemapTask.targetNamespace)
            mappings.set(this@RemapTask.mappings)
            classpath.from(this@RemapTask.classpath)
            cacheDirectory.set(this@RemapTask.cacheDirectory)
            outputFile.set(this@RemapTask.outputFile)
        }
    }

    interface RemapWorkParameters : WorkParameters {
        val inputFile: RegularFileProperty
        val sourceNamespace: Property<String>
        val targetNamespace: Property<String>
        val mappings: RegularFileProperty
        val classpath: ConfigurableFileCollection
        val cacheDirectory: DirectoryProperty
        val outputFile: RegularFileProperty
    }

    abstract class RemapWorkAction : WorkAction<RemapWorkParameters> {
        override fun execute() {
            val cacheKey = buildList<Path> {
                addAll(parameters.classpath.map { it.toPath() })
                add(parameters.mappings.getAsPath())
                add(parameters.inputFile.getAsPath())
            }

            cacheExpensiveOperation(
                parameters.cacheDirectory.getAsPath(),
                "remap-$REMAP_OPERATION_VERSION",
                cacheKey,
                parameters.outputFile.getAsPath()
            ) { (output) ->
                val mappings = loadCachedMappingFile(parameters.mappings.getAsPath())

                JarRemapper.remap(
                    mappings,
                    parameters.sourceNamespace.get(),
                    parameters.targetNamespace.get(),
                    parameters.inputFile.getAsPath(),
                    output,
                    parameters.classpath,
                )
            }
        }
    }
}