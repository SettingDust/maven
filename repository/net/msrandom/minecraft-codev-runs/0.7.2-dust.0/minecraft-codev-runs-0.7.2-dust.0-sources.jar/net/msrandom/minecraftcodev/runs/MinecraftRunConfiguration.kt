package net.msrandom.minecraftcodev.runs

import net.msrandom.minecraftcodev.core.task.CachedMinecraftParameters
import net.msrandom.minecraftcodev.core.task.convention
import net.msrandom.minecraftcodev.core.utils.extension
import net.msrandom.minecraftcodev.core.utils.lowerCamelCaseGradleName
import net.msrandom.minecraftcodev.runs.task.PrepareRun
import net.msrandom.minecraftcodev.runs.task.RunMinecraft
import org.gradle.api.Action
import org.gradle.api.Named
import org.gradle.api.Project
import org.gradle.api.Task
import org.gradle.api.file.DirectoryProperty
import org.gradle.api.file.FileSystemLocation
import org.gradle.api.model.ObjectFactory
import org.gradle.api.plugins.ApplicationPlugin
import org.gradle.api.provider.ListProperty
import org.gradle.api.provider.MapProperty
import org.gradle.api.provider.Property
import org.gradle.api.provider.Provider
import org.gradle.api.tasks.*
import org.gradle.jvm.toolchain.JavaLanguageVersion
import org.gradle.jvm.toolchain.JavaToolchainService
import org.gradle.kotlin.dsl.listProperty
import org.gradle.kotlin.dsl.register
import java.io.File
import java.nio.file.Path
import javax.inject.Inject
import kotlin.io.path.absolutePathString

abstract class MinecraftRunConfiguration @Inject constructor(
    private val name: String,
    val project: Project,
    private val objectFactory: ObjectFactory
) : Named {
    abstract val mainClass: Property<String>
        @Input
        get

    // TODO Set this by default in fabric runs
    abstract val jvmVersion: Property<Int>
        @Input
        get

    abstract val sourceSet: Property<SourceSet>
        @Input
        get

    abstract val beforeRun: ListProperty<Task>
        @Input
        get

    abstract val dependsOn: ListProperty<MinecraftRunConfiguration>
        @Input
        get

    abstract val arguments: ListProperty<String>
        @Input
        get

    abstract val jvmArguments: ListProperty<String>
        @Input
        get

    abstract val properties: MapProperty<String, String>
        @Input
        get

    abstract val environment: MapProperty<String, String>
        @Input
        get

    abstract val workingDirectory: DirectoryProperty
        @InputDirectory
        get

    abstract val cacheParameters: CachedMinecraftParameters
        @Nested
        get

    private val runConfigs = project.layout.buildDirectory.dir("run-configs")
    private val configFileName = name.replace(':', '-')

    val friendlyName
        get() = if (project == project.rootProject) {
            "Run :$name"
        } else {
            "Run ${project.path}:$name"
        }

    val prepareTask: TaskProvider<PrepareRun> =
        project.tasks.register<PrepareRun>(
            lowerCamelCaseGradleName("prepare", ApplicationPlugin.TASK_RUN_NAME, name)
        ) {
            arguments.addAll(this@MinecraftRunConfiguration.arguments)
            jvmArguments.addAll(this@MinecraftRunConfiguration.jvmArguments)

            properties.putAll(this@MinecraftRunConfiguration.properties)

            environment.putAll(this@MinecraftRunConfiguration.environment)

            configFile.set(runConfigs.map { it.file("$configFileName-config.json") })
        }

    val runTask: TaskProvider<RunMinecraft> =
        project.tasks.register<RunMinecraft>(lowerCamelCaseGradleName(ApplicationPlugin.TASK_RUN_NAME, name)) {
            javaLauncher.set(project.extension<JavaToolchainService>().launcherFor {
                languageVersion.set(this@MinecraftRunConfiguration.jvmVersion.map(JavaLanguageVersion::of))
            })

            configFile.set(prepareTask.flatMap(PrepareRun::configFile))
            argFile.set(runConfigs.map { it.file("$configFileName-args.txt") })
            mainClass.set(this@MinecraftRunConfiguration.mainClass)

            workingDir(this@MinecraftRunConfiguration.workingDirectory)

            classpath = project.files(this@MinecraftRunConfiguration.sourceSet.map(SourceSet::getRuntimeClasspath))

            group = ApplicationPlugin.APPLICATION_GROUP

            dependsOn(
                this@MinecraftRunConfiguration.dependsOn.map {
                    it.map(MinecraftRunConfiguration::runTask)
                },
            )

            dependsOn(this@MinecraftRunConfiguration.sourceSet.map(SourceSet::getClassesTaskName))
            dependsOn(this@MinecraftRunConfiguration.beforeRun)
        }

    init {
        run {
            mainClass.finalizeValueOnRead()
            jvmVersion.finalizeValueOnRead()

            sourceSet.convention(project.extension<SourceSetContainer>().named(SourceSet.MAIN_SOURCE_SET_NAME))

            beforeRun.finalizeValueOnRead()
            arguments.finalizeValueOnRead()
            properties.finalizeValueOnRead()
            environment.finalizeValueOnRead()

            workingDirectory
                .convention(project.layout.projectDirectory.dir("run"))
                .finalizeValueOnRead()

            cacheParameters.convention(project)
        }
    }

    fun mainClass(mainClass: String) = apply {
        this.mainClass.set(mainClass)
    }

    fun jvmVersion(jvmVersion: Int) = apply {
        this.jvmVersion.set(jvmVersion)
    }

    fun sourceSet(sourceSet: String) = apply {
        this.sourceSet.set(project.extension<SourceSetContainer>().named(sourceSet))
    }

    fun sourceSet(sourceSet: Provider<SourceSet>) = apply {
        this.sourceSet.set(sourceSet)
    }

    fun sourceSet(sourceSet: SourceSet) = apply {
        this.sourceSet.set(sourceSet)
    }

    fun beforeRun(task: Provider<out Task>) = apply {
        beforeRun.add(task)
    }

    fun beforeRun(vararg tasks: Task) = apply {
        beforeRun.addAll(tasks.toList())
    }

    fun beforeRun(vararg taskNames: String) = apply {
        for (taskName in taskNames) {
            beforeRun.add(project.tasks.named(taskName))
        }
    }

    fun dependsOn(vararg runConfigurations: MinecraftRunConfiguration) = apply {
        dependsOn.addAll(runConfigurations.toList())
    }

    fun args(vararg args: Any?) = arguments(*args)

    fun arguments(vararg args: Any?) = apply {
        arguments.addAll(args.map(Any?::toString))
    }

    fun jvmArgs(vararg args: Any?) = jvmArguments(*args)

    fun jvmArguments(vararg args: Any?) = apply {
        jvmArguments.addAll(args.map(Any?::toString))
    }

    fun prop(key: String, value: String) = property(key, value)

    fun property(key: String, value: String) = apply {
        properties.put(key, value)
    }

    fun prop(key: String, value: Provider<String>) = property(key, value)

    fun property(key: String, value: Provider<String>) = apply {
        properties.put(key, value)
    }

    fun props(vararg properties: Pair<String, String>) = properties(*properties)

    fun properties(vararg properties: Pair<String, String>) = apply {
        this.properties.putAll(properties.toMap())
    }

    fun props(properties: Map<String, String>) = properties(properties)

    fun properties(properties: Map<String, String>) = apply {
        this.properties.putAll(properties)
    }

    fun props(properties: Provider<Map<String, String>>) = properties(properties)

    fun properties(properties: Provider<Map<String, String>>) = apply {
        this.properties.putAll(properties)
    }

    fun env(variables: Map<String, Any>) = environment(variables)

    fun env(vararg variables: Pair<String, Any>) = environment(*variables)

    fun env(
        key: String,
        value: Any,
    ) = environment(key, value)

    fun environment(variables: Map<String, Any>) = apply {

        environment.putAll(variables.mapValues(Any::toString))
    }

    fun environment(vararg variables: Pair<String, Any>) = environment(variables.toMap())

    fun environment(
        key: String,
        value: Any,
    ) = apply {

        environment.put(key, value.toString())
    }

    fun executableDir(path: Any) = apply {
        workingDirectory.set(project.file(path))
    }

    fun executableDirectory(path: Any) = apply {
        workingDirectory.set(project.file(path))
    }

    fun workingDir(path: Any) = apply {
        workingDirectory.set(project.file(path))
    }

    fun workingDirectory(path: Any) = apply {
        workingDirectory.set(project.file(path))
    }

    fun runDir(path: Any) = apply {
        workingDirectory.set(project.file(path))
    }

    fun runDirectory(path: Any) = apply {
        workingDirectory.set(project.file(path))
    }

    fun defaults(action: Action<RunConfigurationDefaultsContainer>) {
        val defaults = project.extension<RunsContainer>().extension<RunConfigurationDefaultsContainer>()

        defaults.configuration = this

        action.execute(defaults)
    }

    override fun getName() = name

    companion object {
        private fun mapArgumentPart(part: Any?) = when (part) {
            is Path -> part.absolutePathString()
            is File -> part.absolutePath
            is FileSystemLocation -> part.toString()
            else -> part.toString()
        }

        fun compileArguments(objectFactory: ObjectFactory, arguments: Iterable<Any?>): ListProperty<String> =
            objectFactory.listProperty<String>().apply {
                for (argument in arguments) {
                    if (argument is Provider<*>) {
                        add(argument.map(::mapArgumentPart))
                    } else {
                        add(mapArgumentPart(argument))
                    }
                }
            }

        /**
         * Compile lazy & immediate parts into one joined argument provider
         * For example,
         * ```
         * val path = provider { "mypath" }
         * compileArgument("-Dsys.prop=", path)
         * ```
         * Would give a provider for `-Dsys.prop=mypath`
         */
        fun compileArgument(objectFactory: ObjectFactory, vararg parts: Any?): Provider<String> =
            compileArguments(objectFactory, parts.toList()).map {
                it.joinToString("")
            }
    }
}
